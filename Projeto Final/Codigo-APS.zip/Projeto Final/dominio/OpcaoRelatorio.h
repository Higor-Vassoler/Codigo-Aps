#ifndef OPCAORELATORIO_H
#define OPCAORELATORIO_H

enum class OpcaoRelatorio
{
    VisualizarGrafico,
    AdicionarMetrica,
    ConfirmarMetrica,
    CancelarMetrica
};

#endif
