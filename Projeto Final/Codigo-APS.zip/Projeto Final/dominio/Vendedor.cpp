#include "dominio/Vendedor.h"

Vendedor::Vendedor(const std::string &nome)
    : nome_(nome) {}
