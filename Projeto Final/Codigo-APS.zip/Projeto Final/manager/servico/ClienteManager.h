#ifndef CLIENTEMANAGER_H
#define CLIENTEMANAGER_H

#include <string>

class ClienteManager
{
public:
    void listarClientesReserva(int idCliente, const std::string &nome);
};

#endif
