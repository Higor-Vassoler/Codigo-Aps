#include "manager/servico/CalculadoraMetricas.h"

std::string CalculadoraMetricas::calcular(const TipoMetrica &)
{
    return "Valores estatísticos calculados";
}
